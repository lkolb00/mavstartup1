<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
</script>

<template>
</template>
