<?php

use App\Http\Controllers\AuthSocialController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::group([], function () {
    Route::get('/dashboard', function () {
        return Inertia::render('Dashboard');
    })->name('dashboard');

    Route::get('/visualization', function () {
        return Inertia::render('ScatterPlot_ResourcePerformance');
    })->name('visualization');

    Route::get('/peer-groups', function () {
        return Inertia::render('PeerGroups');
    })->name('peer-groups');

    Route::get('/about', function () {
        return Inertia::render('About');
    })->name('about');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {

});

Route::get('auth/{provider}/redirect', [AuthSocialController::class, 'handleRedirect']);
Route::get('auth/{provider}/callback', [AuthSocialController::class, 'handleCallback']);
